---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
image: "/images/"
tags: []
---