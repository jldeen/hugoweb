---
layout: contact
title: Contact
image: 'https://via.placeholder.com/1200x800'
---

Menca comes with a built-in contact form, that you can use with Formspree service to handle up to 50 submissions per month for free. You could also easily switch to another contact form service if you want.